package com.beth.test;

 import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import javax.inject.Inject;
import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;
import java.util.*;

 
public class QuestionServiceDAO {

    @Inject
    EntityManager em;

    @Inject
    Logger log;
    Set<String>  vehicles = new HashSet<String>();




    /**
     * @param offset
     * @param limit
     * @return
     */
    public List<Question> getQuestions(int offset, int limit) {
        Session session = em.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Loacation.class)
                .addOrder(Order.asc("questonName"))                
                .setMaxResults(limit)
                .setFirstResult(offset);
        return criteria.list();
    }


    /**
     *

     * @return
     */
    public List<Question> getAllQuestions() {
        Session session = em.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Question.class);
        return criteria.list();
    }


 
    public List<Question> getQuestionByName(String questionname,int offset, int limit) {
        Session session = em.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Loacation.class);
        criteria.addOrder(Order.asc("questionname"));
         
        criteria.setFirstResult(offset);
        criteria.setMaxResults(limit);

 
        return criteria.list();
    }
 
    public Question saveQuetion(Question question) {
        try {
            em.getTransaction().begin();
            em.persist(question);
            em.getTransaction().commit();
        } catch (Exception e) {
            log.error(e);
            em.getTransaction().rollback();
        }
        return question;
    }


}
