
// QUESTION 3

package com.crunchbits.services.api;

import com.beth.test;

import org.apache.log4j.Logger;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Date;
import java.util.List;


@Path("/api")
@Produces(MediaType.APPLICATION_JSON)
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,MediaType.APPLICATION_OCTET_STREAM,MediaType.TEXT_PLAIN,MediaType.MULTIPART_FORM_DATA})
public class QuestionRestAPI {




    @Inject
    QuestionServiceDAO questionServiceDAO;


    @Inject
    Logger log;

    @POST
    @Path("/questions/get")
    public Question get(@QueryParam("questionNumber") String questionNumber) {

        return questionServiceDAO.getByQuestionNumber(questionNumber);

    }


 

    @GET
    @Path("/question/list")
    public List<Question> list(String exam) {
       
            return questionServiceDAO.listQuestionByexam(exam);

    }



    }



}