package com.beth.test;




public class Question{
	
	
	
	private String questionNumber;
	
	private String question;
	
	private List<String> multipleChoice;
	
	private String answer;
	
	
	public void setQuestionMumber(String questionNumber){
		this.questionNumber=questionNumber;
	}
	
	public void setAnswer(Strint answer){
		this.answer=answer;
	}


    public void setQuestion(String question){
		this.question=question;
	}
	
	public void getQuestion(String question){
		return question;
	}
	
	public void setAnswer(String answer){
		this.answer=answer;
	}
	
	public void getAnswer(String answer){
		return answer;
	}
	
	public void setMultipleChoice(List<String> multipleChoice){
		this.multipleChoice=multipleChoice;
		
	}
	public List<String> getMultipleChoice(){
		return multipleChoice;
		
	}



}
