var app = angular.module("sampleApp", ['ui.bootstrap'], function(){});

app.service("airportService", ['$http',
	function($http) {
		var getQuestion = function() {
			return $http({
				method: 'GET',
				url: "api/question"
			});
		};

		var searchQuestion = function(str) {
			return $http({
				method: 'GET',
				url: "api/question/get/" + str
			});
		};

		var saveQuestion  = function(airport) {
			return $http({
				method: "POST",
				url: "api/question",
				data: airport
			});
		};

		var updateQuestion = function(airport) {
			return $http({
				method : "PUT",
				url : "api/question",
				data : airport
			});
		};

		var deleteQuestion = function(id) {
			return $http({
				method: 'DELETE',
				url: "api/question/" + id
			});
		};

		return {
			getQuestion : getQuestion,
			searchQuestion : searchQuestion,
			saveQuestion : saveQuestion,
			updateQuestion : updateQuestion,
			deleteQuestion : deleteQuestion
		};
	}
]);

app.controller("sampleController", ["$scope","questionService", "$modal", function($scope, airportService, $modal) {
	$scope.searchQuestions = "";
	$scope.airports = [];
	$scope.selectedAirport = {};

	$scope.searchQuestions = function() {
		airportService.searchQuestions($scope.searchQuestions).then(function(result) {
			if (result) {
				$scope.airports = result.data;
			}
		});
	};
	$scope.getQuestions = function() {
		questionService.getQuestions().then(function(result) {
			if (result) {
				$scope.airports = result.data;
			}
		});
	};

 
	$scope.markQuestionModal = function (question) {
		$scope.selectedQuestion = question;

		 
	};

	 

}]);
 